# Philippines v12 ENV_WATER diagnostic case

This case is generated from `Philippines_v12_ENV_LAND`. It retains the exact
eight-mode `ENV_LAND` account and adds an **unforced diagnostic**
three-mode `ENV_WATER` technology:

1. water vapor returned;
2. modeled raw groundwater remaining; and
3. modeled raw surface water remaining.

`ENV_WATER` has no balance constraint and is not an authoritative account.
Its activity may be zero, partial, or complete because the standard commodity
balances permit unused production. Compare its activity with the authoritative
production-minus-ordinary-use ledger in:

`../../../Philippines_v12_CLEWs_build/diagnostics/environmental_accounting/`

- Generator:
  `../../../Philippines_v12_CLEWs_build/scripts/generate_environmental_water_diagnostic_case.py`
- Reporter:
  `../../../Philippines_v12_CLEWs_build/scripts/report_environmental_accounting.py`
- Validator:
  `../../../Philippines_v12_CLEWs_build/scripts/validate_environmental_water_diagnostic_case.py`
- Pivot publisher:
  `../../../Philippines_v12_CLEWs_build/scripts/publish_environmental_water_pivot.py`
- Local documentation index: `documentation/README.md`

After each solve, the Pivot publisher can place the authoritative reference
under the existing `ENV_WATER` name in all linked Results Pivot variables.
It leaves raw solver CSVs and this model topology unchanged and backs up the
solver-generated views. Do not edit generated solver inputs, outputs, CSV
files, or Pivot files by hand.

When this case is installed from the `CLEWs-PHL` portable archive into a
separate MUIOGO checkout, run the publisher from the `CLEWs-PHL` repository
and pass the installed case explicitly:

```bash
PYTHONHASHSEED=0 python \
  Philippines_v12_CLEWs_build/scripts/publish_environmental_water_pivot.py \
  --model /path/to/MUIOGO/WebAPP/DataStorage/Philippines_v12_ENV_LAND_WATER_DIAGNOSTIC \
  --label <unique-label>
```
