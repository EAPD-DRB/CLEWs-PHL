# Philippines v12 environmental-land case

This is a derived MUIO case generated from `Philippines_v12`. It adds exact
in-model land accounting through the eight-mode `ENV_LAND` terminal and
`BAL_ENV_LAND` equality constraint. The source case remains unchanged.

Water accounting remains reporting-only because the installed
technology-level user-defined constraint cannot reproduce the source model's
mode-dependent water coefficients exactly.

- Accounting guide, generator, validator, and current evidence:
  https://github.com/EAPD-DRB/CLEWs-PHL/tree/main/Philippines_v12_CLEWs_build
- Local documentation index: `documentation/README.md`

Do not edit generated `data.txt`, solver output, or result CSV files by hand.
Regenerate this case from the source JSON with the documented generator.
