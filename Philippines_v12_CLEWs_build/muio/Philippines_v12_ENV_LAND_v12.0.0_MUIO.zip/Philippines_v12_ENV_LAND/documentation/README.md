# Environmental-land case documentation

The canonical current documentation is kept in the v12 build package:

- `../../../../Philippines_v12_CLEWs_build/documentation/ENVIRONMENTAL_ACCOUNTING.md`
- `../../../../Philippines_v12_CLEWs_build/documentation/CURRENT_MODEL.md`
- `../../../../Philippines_v12_CLEWs_build/data_sources/`

This runtime case contains `ENV_LAND` as an eight-mode MUIO technology:

1. forest
2. grassland
3. other land
4. barren or savannah
5. built-up land
6. inland water bodies
7. cropland
8. unallocated modeled land

`ENV_WATER` is intentionally absent. Use the reporting workflow documented in
the canonical environmental-accounting guide.
