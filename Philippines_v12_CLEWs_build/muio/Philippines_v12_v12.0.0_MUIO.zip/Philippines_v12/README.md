# Philippines v12 active MUIO case

This folder contains the portable editable MUIO case. Solver inputs and
results are generated after the case is opened and solved in MUIOGO.

The current model combines the historical v10 energy system, Fisheries
**v2.3**, and the v12 CLEWs Global-derived land–agriculture–water block. The
parameter JSON files remain at this level because MUIO expects them here.

- Current case documentation: `documentation/README.md`
- Current Fisheries v2.3 data records:
  `documentation/data_sources/fisheries/`
- Dated and superseded records: `documentation/history/`
- Canonical sources, assumptions, calculations, model map, history, and
  diagnostics:
  https://github.com/EAPD-DRB/CLEWs-PHL/tree/main/Philippines_v12_CLEWs_build
- Derived in-model land-accounting case:
  `../Philippines_v12_ENV_LAND/`

Historical files may contain old filenames and version language because they
record the state at that date. They are not the current instructions.

The parameter JSON files in this source case were not changed by the
accounting addition. Water and source-case land accounts can still be
generated as reports. The separate derived case contains the exact in-model
`ENV_LAND` terminal; `ENV_WATER` remains reporting-only.
