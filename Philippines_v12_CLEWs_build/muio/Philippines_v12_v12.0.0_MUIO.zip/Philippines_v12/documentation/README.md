# Philippines v12 case documentation

## Current

- Fisheries v2.3 source register:
  `data_sources/fisheries/DATA_SOURCE_REGISTER_v2.3.md`
- Fisheries v2.3 calculation record:
  `data_sources/fisheries/FSH_CALIBRATION_v2.3.md`
- Fisheries v2.3 comparison:
  `data_sources/fisheries/FSH_GLOBAL_PARITY_v2.3.md`
- Fisheries v2.3 evidence tables:
  `data_sources/fisheries/FSH_calibration_data_v2.3.csv` and
  `data_sources/fisheries/FSH_industry_carveout_v2.3.csv`

The cross-sector source register and model history live in the build package:

- `../../../../Philippines_v12_CLEWs_build/data_sources/`
- `../../../../Philippines_v12_CLEWs_build/documentation/`
- `../../../../Philippines_v12_CLEWs_build/documentation/ENVIRONMENTAL_ACCOUNTING.md`

The exact in-model land-accounting case is a sibling runtime case:

- `../../Philippines_v12_ENV_LAND/`

The source case in this folder remains unchanged; water accounting remains
reporting-only in both cases.

## History

`history/` contains dated build notes and superseded formulations grouped by
subject or model stage. Their content is preserved. Old relative paths inside
those files show where supporting files were at the time and are not current
navigation instructions.
