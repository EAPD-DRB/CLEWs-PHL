# Philippines v12 Fisheries v2.3 import — 25 July 2026

## Outcome

The authoritative Fisheries v2.3 sector from `Philippines_v10` replaces the
previous Fisheries v2.2 parameter state in `Philippines_v12`. The v12 energy,
land, agriculture, water, climate, and emissions records outside this explicit
sector boundary are unchanged.

The imported boundary comprises:

- all seven Fisheries technology definitions and parameters;
- all four Fisheries commodity definitions and parameters; and
- the `PHL_INDU_OTH` specified-demand row affected by the direct
  fish-processing useful-service carve-out.

V12’s 30-mode dimension-expansion records are retained because they are part
of the nexus integration structure and have no v10 key to replace.

## Active model changes

The existing v12 case already matched v10 for Fisheries demand, technology
definitions, conversion ratios, costs, operating lives, emissions, open
activity/investment bounds, and all other Fisheries records. The v2.3 import
therefore changes exactly 12 dimensioned records:

- six end-use `AvailabilityFactor` rows are set to 1;
- five nonzero `ResidualCapacity` paths are restored and retired over their
  documented 8- or 15-year operating lives; and
- one `PHL_INDU_OTH` `SpecifiedAnnualDemand` row is replaced with the direct
  one-for-one `PHL_FSH_PRO` useful-service carve-out.

There are no Fisheries-only user-defined constraints, exact historical
activity pins, or special deployment dates.

## Verification

- Fisheries definitions/parameter records checked against v10 v2.3: 2,115
- Fisheries scalar values checked against v10 v2.3: 140
- Fisheries mismatches: 0
- Non-Fisheries records changed by the import: 0
- Full retained-v10 preservation audit: PASS
- Validation suite: 10/10 PASS
- Crop-balance audit after both solves: PASS

Both active v12 runs were regenerated through the full MUIO
data-generation, preprocessing, GLPK matrix-generation, CBC solve, CSV, and
viewer pipeline:

| Run | Status | Objective |
|---|---|---:|
| `Base_v12` | Optimal | 375,930,821.3405416 |
| `PEP_v12` | Optimal | 375,953,763.4595271 |

The endogenous 2020 Fisheries result is the same in both runs to the displayed
activity precision:

| Technology | Activity (PJ useful) | New capacity (GW useful) |
|---|---:|---:|
| `PHL_FSH_MOT_LIQ` | 1.4562 | 0 |
| `PHL_FSH_MOT_ELE` | 0 | 0 |
| `PHL_FSH_AQC_LIQ` | 3.9143 | 0.1128 |
| `PHL_FSH_AQC_ELE` | 1.0783 | 0 |
| `PHL_FSH_PRO_LIQ` | 1.5631 | 0 |
| `PHL_FSH_PRO_ELE` | 0 | 0 |

Most inherited electric-aquaculture stock is left idle. This confirms that
residual capacity represents available historical equipment and does not
force the model to reproduce the stock-estimation carrier split.

## Data-source documentation

The following authoritative v2.3 artifacts were copied unchanged from
`Philippines_v10` into this case:

- `FSH_CALIBRATION.md`
- `FSH_GLOBAL_PARITY.md`
- `FSH_calibration_data.csv`
- `FSH_industry_carveout.csv`

The complete government-review index is
`Philippines_v12_CLEWs_build/sources/fisheries_v2.3/DATA_SOURCE_REGISTER.md`.
It lists the exact named DOE, BFAR, and PSA publications, the variables and
transformations used, the assumptions/proxies requiring review, suggested
review owners, and preferred national replacements.

The imported parameter CSV retains symbolic source tags such as `S4`, `S19`,
and `A16`. The v2.3 bundle does not include the lookup key that expands every
symbolic tag. The source register flags this explicitly; unresolved codes are
not represented as fully traceable citations.

## Audit and recovery

- Import audit:
  `Philippines_v12_CLEWs_build/diagnostics/fisheries_v23_import_audit.json`
- Full preservation audit:
  `Philippines_v12_CLEWs_build/diagnostics/v12_hybrid_audit.json`
- Pre-import portable case:
  `Philippines_v12_CLEWs_build/backups/Philippines_v12_MUIO_pre_Fisheries_v2.3_2026-07-25.zip`
- Pre-import source files:
  `Philippines_v12_CLEWs_build/backups/Philippines_v12_source_pre_Fisheries_v2.3_2026-07-25.zip`
