# Model fixes — 20 July 2026

## Fix 1 — Fisheries v2.1 CBC solve-time regression

### Reason

Fisheries calibration v2 added exact 2020 technology-activity pins by setting
matching lower and upper activity limits. The previously fast `Base_v9` model
then failed to converge reliably in CBC. Controlled A/B tests isolated the FSH
pins as the cause: an otherwise equivalent unpinned case solved optimally in
about 93 seconds, while the exact-pin formulation ran for more than 15 minutes
without an optimum.

### Source changes

Permanent changes were made only in source files:

- `RYT.json`, base scenario `SC_0`: for `TEC_fsh02` through `TEC_fsh07`, all
  annual `TAL` values are now `0` and all annual `TAU` values are `999999`.
- `FSH_calibration_data.csv`: removed the eleven `point:2020` rows that created
  the exact FSH activity bounds, preventing a recalibration run from restoring
  them.
- `genData.json`: changed the case-description label from FSH calibration v2
  to v2.1. No technology, commodity, mode or mapping was structurally changed.
- `FSH_CALIBRATION.md`: documented the runtime correction and its calibration
  tradeoff.

Before the correction, five positive 2020 activities had `TAL = TAU` at their
calibrated values, and electric motive had a zero 2020 upper bound. After the
correction, FSH activities use the standard open bounds in every model year.
Aggregate FSH service demands, IARs, costs, residual capacities, emissions,
the Industry carve-out, and the `TAMaxCI = 0` restriction on electric-motive
investment before 2027 were not changed.

### Diagnostic experiments

All generated-file modifications were confined to a disposable diagnostic
directory and were not promoted. The following CBC tests were run:

| Formulation | Result |
|---|---|
| Exact 2020 FSH `TAL = TAU` pins | No optimum after more than 15 minutes |
| No FSH activity pins | Optimal in 93.13 seconds; objective 375,955,019.54594 |
| Lower bounds only | Timed out after 300 seconds |
| Exact carrier-ratio constraints | Timed out after 307 seconds |
| ±1% activity bands | Timed out / numerically unstable postsolve |
| Activity-capacity locks, including a liquid-only variant | Timed out |
| Native variable bounds and CBC dual simplex | Did not restore convergence |
| Artificial technology-cost penalties | Solved in 88–95 seconds but did not reproduce the calibrated carrier split; rejected |

The disposable diagnostic LPs and result files were deleted after recording
these results because they occupied 3.8 GB. The reproducible validation scripts
remain under `tmp/fsh-scaffold/`, and the pre-correction source backup remains
under `tmp/fsh-runtime-fix-backup-PN5SDU/`.

### Required validation chain

A fresh disposable copy of the edited `Philippines_v10` case was validated
through the normal application path:

1. `DataFile(case).generateDatafile(run)`: **passed**.
2. `preprocessData()`: **passed**.
3. Source/export inspection: **passed**; FSH `TAL = 0`, `TAU = 999999`, and
   the pre-2027 electric-motive `TAMaxCI` restriction survived export. No FSH
   technology/mode mapping changed.
4. `glpsol --check` and LP generation: **passed**; the generated matrix had
   558,339 rows and 468,046 columns.
5. CBC optimization: **passed**, optimal in about 90 seconds with objective
   **375,955,019.54594**.
6. Case identity: the disposable run was generated from `Philippines_v10`,
   calibration v2.1, on 20 July 2026. Live `res/` outputs were not overwritten.

The solved 2020 FSH useful-service totals were:

| Service | Target | Solved |
|---|---:|---:|
| Motive | 1.456223214 | 1.456223200 |
| Aquaculture | 4.992662319 | 4.992662300 |
| Processing | 1.563068182 | 1.563068200 |

Electric motive remained zero. The optimized technology activities were
`AQC_LIQ = 3.9743614`, `AQC_ELE = 1.0183009`, `PRO_LIQ = 1.5630682`, and
`PRO_ELE = 0`. Thus aggregate service calibration is preserved, but the
observed aquaculture and processing carrier splits are no longer enforced.

### Baseline and incomplete comparisons

The exact-pin baseline never produced an optimal solution, so a valid objective
percentage change relative to that formulation cannot be calculated. The live
`res/Base_v9/results.txt`, modified 20 July 2026 at 15:44 EDT, begins `Stopped
on iterations` with objective 10,841,400,324.89759 and is not a valid baseline
or a valid v2.1 result. The saved `PEP_v9` result is a different scenario and
was not used as a baseline.

Full system-wide comparisons of non-FSH activities, capacities, emissions,
constraint residuals and duals were **not run** because there is no valid
optimal exact-pin result to compare against. Accordingly, v2.1 is validated
for generation, matrix integrity, optimal solvability, runtime recovery and
the affected aggregate FSH services, but not as a full result-equivalence
comparison. A fresh live Base solve is required before interpreting or
publishing system results.
