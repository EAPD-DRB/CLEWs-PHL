# Model fix — 25 July 2026

## Fisheries-only de-calibration (v2.2)

### Requested scope

Remove Fisheries parameters introduced to make technology use reproduce
historical data. Do not alter any other sector.

### Removed Fisheries forcing

- All `TEC_fsh02`–`TEC_fsh07` annual activity bounds remain open:
  `TAL = 0`, `TAU = 999999`.
- Calibration-derived residual capacity was removed from:
  - `PHL_FSH_MOT_LIQ`;
  - `PHL_FSH_AQC_LIQ`;
  - `PHL_FSH_AQC_ELE`;
  - `PHL_FSH_PRO_LIQ`;
  - `PHL_FSH_PRO_ELE`.
- The `PHL_FSH_MOT_ELE` investment prohibition for 2020–2026 was removed.
  Its `TAMaxCI` is now 999999 in every year.
- Matching rows were removed from `FSH_calibration_data.csv` so the old
  forcing cannot be restored by rerunning the Fisheries input workflow.

### Retained inputs

- Fisheries motive, aquaculture and processing useful-service demands.
- Technology efficiencies and input/output activity ratios.
- Capital and fixed costs.
- Availability factors, operating lives and capacity-to-activity units.
- Emission factors.
- Fisheries/Industry accounting boundary and the existing processing
  carve-out from aggregate Industry demand.
- All non-Fisheries model parameters and scenario constraints.

Service demand is retained because the model minimizes cost and has no
utility function: setting Fisheries demand to zero would make zero Fisheries
activity the mathematically correct answer, not an endogenous estimate of
real demand.

### Interpretation

The DOE carrier balance remains documented as external evidence, but it is no
longer a target that the model must match. Starting in 2020, the optimizer is
free to choose Fisheries liquid/electric technology shares and build the
capacity required to meet the exogenous useful-service demands.

### Verification

The Base case was regenerated and solved through MUIO's normal
`generateDatafile` → `preprocessData` → GLPK LP generation → CBC → CSV/viewer
pipeline.

- CBC 2.10.12 status: **Optimal**.
- Objective: **375,955,297.586932**.
- CBC wall-clock solve time: **138.85 seconds**.
- Complete MUIO pipeline time: **177.34 seconds**.
- Matrix: 558,339 rows; 468,046 columns; 4,483,538 nonzeros.

The endogenous 2020 Fisheries result is:

| Technology | Activity (PJ useful) | New capacity (GW useful) |
|---|---:|---:|
| `PHL_FSH_MOT_LIQ` | 1.4562232 | 0.3848044 |
| `PHL_FSH_MOT_ELE` | 0 | 0 |
| `PHL_FSH_AQC_LIQ` | 3.9743614 | 0.4200872 |
| `PHL_FSH_AQC_ELE` | 1.0183009 | 0.1076337 |
| `PHL_FSH_PRO_LIQ` | 1.5630682 | 0.1101435 |
| `PHL_FSH_PRO_ELE` | 0 | 0 |

Fisheries delivered electricity is 1.171046 PJ. The technology mix happens
to equal the prior unpinned least-cost result, but it is now supported entirely
by endogenous 2020 investment rather than calibration-derived residual stock
or a technology-availability restriction.

The previous v2.1 objective was 375,955,019.545940. Removing the free inherited
Fisheries stock raises total discounted cost by 278.040992 (about 0.000074%)
because the optimizer must purchase the selected Fisheries capacity.

An archive comparison confirmed that no non-Fisheries source parameter file
changed.

The PEP case was then regenerated through the same complete pipeline.

- CBC 2.10.12 status: **Optimal**.
- Objective: **375,978,103.361333**.
- CBC wall-clock solve time: **280.97 seconds**.
- Complete MUIO pipeline time: **319.20 seconds**.

The endogenous PEP 2020 Fisheries result is:

| Technology | Activity (PJ useful) | New capacity (GW useful) |
|---|---:|---:|
| `PHL_FSH_MOT_LIQ` | 1.4562232 | 0.3848044 |
| `PHL_FSH_MOT_ELE` | 0 | 0 |
| `PHL_FSH_AQC_LIQ` | 3.9878780 | 0.4215159 |
| `PHL_FSH_AQC_ELE` | 1.0047843 | 0.1062050 |
| `PHL_FSH_PRO_LIQ` | 1.5630682 | 0.1101435 |
| `PHL_FSH_PRO_ELE` | 0 | 0 |

PEP Fisheries delivered electricity is 1.155502 PJ. The small difference
from Base is an endogenous response to the PEP scenario, not a historical
calibration constraint.

### Backup

The pre-change source and saved-case outputs are preserved at the repository
root as:

`Philippines_v10_pre_Fisheries_decalibration_2026-07-25.zip`

`Philippines_v10_Base_v10_pre_Fisheries_decalibration_2026-07-25.zip`

`Philippines_v10_PEP_v10_pre_Fisheries_decalibration_2026-07-25.zip`
