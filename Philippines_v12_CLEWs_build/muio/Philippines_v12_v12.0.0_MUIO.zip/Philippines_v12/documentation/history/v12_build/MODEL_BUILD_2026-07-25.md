# Philippines v12 model build — 25 July 2026

Philippines v12 preserves the v10 energy system, imports the current v10
Fisheries v2.3 sector, and replaces the retired placeholder land block with a
raw, country-specific CLEWs Global land–agriculture–water system.

## Final structure

- 172 technologies and 92 commodities
- 2020–2053
- inherited 30-timeslice v10 chronology
- 42 new nexus technologies
- eight spatial land clusters covering 295,813.1 km²
- 24 crop-land options
- six crop outputs: rice, coconuts, maize, vegetables, sugar cane, and other
  crops
- connected agricultural electricity, surface water, groundwater,
  precipitation, evapotranspiration, and total land

The full source, adaptation, and validation package is
`Philippines_v12_CLEWs_build/` at the repository root. The v10 land
calibration file has been renamed `LAND_CALIBRATION_v10_RETIRED.md` and is
lineage documentation only.

## Preservation

After the Fisheries v2.3 import, the automated audit found zero mismatches
against the current v10 across all 130 retained v10
technology definitions, all 55 retained commodity definitions, 36,780
dimensioned parameter records, and 2,612 scalar parameter values. All seven
Fisheries technologies and their v10-keyed parameters match v10 v2.3.

The sector import itself changed no non-Fisheries record. Its exact scope,
source documentation, audits, and recovery packages are listed in
`FISHERIES_V23_IMPORT.md`.

## Solver verification

- Base v12: Optimal; objective 375,930,821.3405416
- PEP v12: Optimal; objective 375,953,763.4595271

Both runs completed with zero primal infeasibility.

## Calibration status

The added nexus is a technically valid, uncalibrated raw build. It contains
no historical equality locks, no inherited policy constraint memberships,
and no scenario overrides. The positive land-cover mode minima come directly
from geospatial built-up/water shares and do not equal upper limits.

Use this case for structural exploration or as the input to a separately
scoped calibration exercise; do not treat raw nexus outputs as validated
historical estimates.
