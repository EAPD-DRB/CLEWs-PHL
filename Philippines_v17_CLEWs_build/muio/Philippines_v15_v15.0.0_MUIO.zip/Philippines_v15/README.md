# Philippines_v15 national water case

This is the validated MUIO/MUIOGO Philippines v15 case. It inherits the
Philippines v14 stock-turnover model and adds a national precipitation and
renewable-water envelope for 2020-2053.

## Water changes in v15

- The inherited hydrology coefficients are rebased to the World Bank CCKP
  ERA5 1991-2020 national precipitation normal.
- One CMIP6 SSP2-4.5 ensemble-median precipitation path is installed. The
  retained p10 and p90 values are evidence only; users may construct their own
  scenarios from them.
- `DEMAGRGWTPHL` consumes raw groundwater one-for-one in its active mode.
- `WATER_SUR_AVAIL` limits annual gross surface-water withdrawal by the three
  surface-water pass-through technologies.
- `WATER_GWT_POTENTIAL` similarly limits the three groundwater pass-through
  technologies.

The model remains a whole-country formulation. The two ceilings are national
potential-flow sensitivities, not basin allocation, dependable yield,
environmental-flow-adjusted availability, aquifer storage, or groundwater safe
yield. Neither ceiling binds in `BASE_V15`.

The inherited `ENV_LAND` account remains exact. The inherited `ENV_WATER`
technology remains an unforced diagnostic and is not an authoritative water
terminal. Use `documentation/national_water_ledger.json` for the validated
full-precision annual water publication.

## Audit files

- `documentation/MODEL_FIXES_WATER_2026-08-04.md`
- `documentation/national_water_manifest.json`
- `documentation/national_water_validation.json`
- `documentation/national_water_ledger.json`
- `documentation/philippines_water_precipitation_ssp245.json`

The canonical six-table source ledger, calculation note, retained evidence,
and schema-validation reports are distributed with the
`Philippines_v15_CLEWs_build` package in the CLEWs-PHL repository.

Generated solver inputs and results are not model sources. Regenerate them
through the normal MUIOGO application chain after installing the case.
