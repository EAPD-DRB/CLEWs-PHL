# Philippines_v15 documentation routing

The inherited `ENV_WATER` diagnostic documentation is kept in the v12 build
package:

- `../../../../Philippines_v12_CLEWs_build/documentation/ENVIRONMENTAL_ACCOUNTING.md`
- `../../../../Philippines_v12_CLEWs_build/documentation/CURRENT_MODEL.md`
- `../../../../Philippines_v12_CLEWs_build/data_sources/`

The canonical source trace for the v15 national-water and climate changes is:

- `../../../../docs/philippines_v15/data_sources/`
- `../../../../docs/philippines_v15/data_sources/DATA_SOURCES.md`
- `../../../../docs/philippines_v15/data_sources/calculation_notes/national_water_v15.md`
- `../../../../docs/philippines_v15/validation/schema_ledger_build.json`
- `../../../../docs/philippines_v15/validation/schema_ledger_live.json`

Those six canonical CSV tables trace the external evidence, calculations,
assumptions, live model mappings, gaps and change history. The accompanying
workbook is a formatted review copy; the CSVs remain authoritative.

This case contains:

- exact in-model `ENV_LAND` modes 1-8;
- unforced diagnostic `ENV_WATER` modes 1-3; and
- no `BAL_ENV_WATER` constraint.

The reporting ledger excludes `ENV_WATER` consumption when calculating the
reference residual, then compares that reference with terminal activity.

The current Results Pivot contains the authoritative postprocessed reference
rather than the unforced solver terminal values. See
`environmental_water_pivot_publication.json` and the canonical evidence
directory. Raw solver CSVs remain unchanged.
