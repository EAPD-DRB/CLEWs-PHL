# Philippines_v17 national land-cover case

This is the complete Philippines v16 MUIO source model plus the v17 national
land-account repair and Philippine land-transition safeguards. The 2020
PSA/NAMRIA seven-class partition is initialized through ENV_LAND equalities;
MINLNDTOT is fixed to 295.8131 thousand km2 in every year; existing LNDOTHTOT
mode 2 is the endogenous idle/fallow cropland route; non-convertible classes
and 2020 total cropland are preserved; and forest expansion follows the
documented policy-rate envelope over the mapped brush/shrub pool. No
technology, commodity, user constraint, or global mode was added. Forest
VC=-10 is unchanged.

See `documentation/MODEL_FIXES_LAND_COVER_2026-08-12.md` and the repository
package `Philippines_v17_CLEWs_build` for the complete cumulative provenance.
Generated solver inputs and results are not model sources and are excluded
from the portable archive.
