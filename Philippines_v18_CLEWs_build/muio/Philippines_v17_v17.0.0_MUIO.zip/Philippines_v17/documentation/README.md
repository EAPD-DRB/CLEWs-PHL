# Philippines_v16 documentation routing

The canonical cumulative source trace is in the repository package
`Philippines_v16_CLEWs_build/data_sources/`. Its six CSV tables trace sources,
calculations, assumptions, live model mappings, gaps, and changes. The CSVs
remain authoritative; the accompanying v16 workbook is a formatted review
copy.

The achieved-crop-yield repair is documented in
`MODEL_FIXES_CROP_YIELDS_2026-08-11.md`. Exact source values, units, commodity
definitions, formulas, hashes, before/after areas, solver evidence, and known
spatial crop-water limitations are in
`Philippines_v16_CLEWs_build/data_sources/calculation_notes/crop_yields_v16_2026-08-11.md`.

The read-only audit of inherited exact annual capacity-investment pins is in
`NON_FORCING_CALIBRATION_REVIEW_2026-08-07.md`. It records an open calibration
finding only; no recommended capacity-bound or model-period change has been
implemented or solved.

The removal of the COAL_PHASEOUT-only 2020-2024 coal-dispatch pins, including
the exact previous values and control/candidate validation, is recorded in
`MODEL_FIXES_COAL_DISPATCH_2026-08-07.md`.

This case contains:

- exact in-model `ENV_LAND` modes 1-8;
- unforced diagnostic `ENV_WATER` modes 1-3; and
- no `BAL_ENV_WATER` constraint.

The reporting ledger excludes `ENV_WATER` consumption when calculating the
reference residual, then compares that reference with terminal activity.

The current Results Pivot contains the authoritative postprocessed reference
rather than the unforced solver terminal values. See
`environmental_water_pivot_publication.json` and the canonical evidence
directory. Raw solver CSVs remain unchanged.
