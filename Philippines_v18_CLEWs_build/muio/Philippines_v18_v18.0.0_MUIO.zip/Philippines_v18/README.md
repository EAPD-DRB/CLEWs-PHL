# Philippines_v18

Complete Philippines v17 source plus the v18 country-specific energy-input
update. The v17 national land account and safeguards are retained. Existing
domestic-gas and LNG import routes are distinguished by price and annual limit;
no technology or commodity is added.

Canonical validation run: `ENERGY_INPUTS_V18_BASE` (optimal objective
369743557.68076980). Generated run files are excluded from the portable
archive.
