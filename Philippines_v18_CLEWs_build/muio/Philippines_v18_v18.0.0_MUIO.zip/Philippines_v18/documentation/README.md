# Philippines_v18 documentation routing

This portable case carries the v18 energy-input and deployment-envelope
normalized records, build manifests, and solved validation reports. The
complete authoritative cumulative provenance ledger and retained evidence are
in the sibling repository package
`Philippines_v18_CLEWs_build/data_sources/`.

V18 inherits the complete v17 national land account. The v17 land build and
validation records retained here document that lineage; the v18 energy records
document the current geothermal, wind, coal, SMR, hydro, and gas inputs. The
deployment-envelope record documents the only later change:
`RYT.json` → `TAMaxCI.SC_0` from 2026 onward.

The portable archive is result-free. Regenerate solver inputs and results from
the editable JSON source before reviewing outputs.
