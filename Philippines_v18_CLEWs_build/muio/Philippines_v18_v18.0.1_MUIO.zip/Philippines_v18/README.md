# Philippines_v18

Complete Philippines v17 source plus the v18 country-specific energy-input
update and policy-neutral generation deployment envelopes. The v17 national
land account and safeguards are retained. Existing domestic-gas and LNG import
routes are distinguished by price and annual limit. From 2026, annual entry is
limited by technology-specific physical delivery envelopes with retirement and
permitted-vintage replacement allowances; no technology or commodity is added.

Canonical deployment-envelope validation run: `DEPLOYMENT_ENVELOPE_V18_BASE`
(optimal objective 369743573.32256168). Generated run files are excluded from
the portable archive.

Land-water closure repair: the eight hydrological clusters are fixed to their existing geographic areas, every cluster-mode conserves water, and gross irrigation withdrawal is converted to delivered field water at the documented 0.38 efficiency. Crop and land-cover modes remain endogenous.
