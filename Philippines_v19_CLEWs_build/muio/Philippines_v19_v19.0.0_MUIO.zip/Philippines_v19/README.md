# Philippines_v19

This editable case is the exact working Philippines v18.0.1 source from Git
commit `2735feb` plus the validated PM2.5 coverage patch. Only `genData.json`
and `RYTEM.json` differ from that baseline.

V19 adds endogenous PM2.5 factors for 52 existing technologies: 46 first-time
links and six liquid-road non-exhaust extensions. CO2e, all unaffected PM2.5
rows, technologies, commodities, demands, costs, capacities, constraints,
`TAMaxCI`, and solver settings are unchanged. The later 2020-2025
deployment-cap experiment is excluded, and no exogenous emission inventory is
included.

The accepted candidate solved optimally in 471.112 seconds end-to-end under a
600-second limit. See `documentation/MODEL_FIXES_PM25_COVERAGE_2026-08-19.md`,
`documentation/pm25_coverage_v19_2026-08-19.json`, and
`documentation/pm25_coverage_v19_validation.json`. The repository build
package contains the complete cumulative six-table schema ledger and retained
source evidence.
